# ADS401 Web Report Scaffold

单页 Web Report 骨架，对应 `ADS401.CourseworkSheet.Report.pdf` 里的 8 个必需章节。

## 文件说明

| 文件 | 用途 |
| --- | --- |
| `ADS401_GroupID_Report.html` | 主页面。提交前把 `GroupID` 换成你们组的编号 |
| `assets/style.css` | 样式，一般不用改 |
| `assets/app.js` | 目录高亮 + 回到顶部，一般不用改 |
| `assets/img/` | 放图表截图的地方 |

## 使用步骤

1. 双击 `ADS401_GroupID_Report.html` 在浏览器里预览。
2. 搜索 `[` 找到所有占位符，逐个替换成你们的内容（橙色虚线标记就是待填位置）。
3. 找到 `1. Project at a glance` 等 8 个章节标题，按课程要求补内容。
4. 把 `GroupID` 替换成真实组号，并重命名文件为 `ADS401_<GroupID>_Report.html`。
5. 上传到 GitHub 仓库，打开 GitHub Pages 即可获得提交链接。

## 必须注意

- 单页，不要拆子页面；章节内跳转用锚点即可。
- 网站和仓库里都不能放原始被试数据。
- 图表要有清晰标题、单位和不确定度；图片要写 `alt` 文本。
- 正文约 2000-2500 词，阅读时间约 10 分钟。
- 提交材料还包括 A1 海报（含指向本页面的二维码）和 Supplementary Materials 压缩包。

## 参考

- 提交文件名: `ADS401_GroupID_Report.html`
- 海报文件名: `ADS401_GroupID_Poster.pdf`
- 补充材料: `ADS401_GroupID_SupplementaryMaterials.zip`
